import USER from "./user";
import ADMIN from "./admin";

const API = {
  user: USER,
  admin: ADMIN,
};

export default API;
