import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ADMIN_API } from "../../../api/admin";
const MatchEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    conditions: {
      level: "중급 이상",
      gender: "혼성",
      matchFormat: "5v5",
      theme: "풋살화",
    },
    participantInfo: {
      minimumPlayers: 0,
      maximumPlayers: 0,
    },
    stats: "",
    startTime: "2025-07-11T10:00:00.000Z",
    durationMinutes: 90,
    subField: {
      _id: "68625da4c216490c6a9a8af7",
    },
    fee: 12000,
  });
  useEffect(() => {
    if (id) {
      fetchMatch();
    } else {
      setLoading(false);
    }
  }, [id]);
  const fetchMatch = async () => {
    try {
      setLoading(true);
      const response = await ADMIN_API.getMatch(id);
      console.log("Match data:", response);
      if (response && response.data) {
        const match = response.data;
        setFormData({
          conditions: match.conditions || formData.conditions,
          participantInfo: match.participantInfo || formData.participantInfo,
          stats: match.stats || formData.stats,
          startTime: match.startTime || formData.startTime,
          durationMinutes: match.durationMinutes || formData.durationMinutes,
          subField: match.subField || formData.subField,
          fee: match.fee || formData.fee,
        });
      }
    } catch (error) {
      console.error("Error fetching match:", error);
      setError("경기 정보를 불러오는 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      if (id) {
        await ADMIN_API.updateMatch(id, formData);
        alert("경기 정보가 성공적으로 수정되었습니다.");
      } else {
        await ADMIN_API.createMatch(formData);
        alert("경기가 성공적으로 생성되었습니다.");
      }
      navigate("/admin/matches");
    } catch (error) {
      console.error("Error saving match:", error);
      setError("경기 저장 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };
  const handleCancel = () => {
    navigate("/admin/matches");
  };
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600">로딩 중...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-md p-8 w-full max-w-xl">
        <h2 className="text-2xl font-bold mb-6 text-gray-900">
          경기 정보 수정
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block font-semibold mb-1">레벨</label>
            <input
              type="text"
              name="level"
              value={formData.conditions.level}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  conditions: { ...prev.conditions, level: e.target.value },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">성별</label>
            <input
              type="text"
              name="gender"
              value={formData.conditions.gender}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  conditions: { ...prev.conditions, gender: e.target.value },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">경기 방식</label>
            <input
              type="text"
              name="matchFormat"
              value={formData.conditions.matchFormat}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  conditions: {
                    ...prev.conditions,
                    matchFormat: e.target.value,
                  },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">테마</label>
            <input
              type="text"
              name="theme"
              value={formData.conditions.theme}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  conditions: { ...prev.conditions, theme: e.target.value },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">최소 인원</label>
            <input
              type="number"
              name="minimumPlayers"
              value={formData.participantInfo.minimumPlayers}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  participantInfo: {
                    ...prev.participantInfo,
                    minimumPlayers: e.target.value,
                  },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">최대 인원</label>
            <input
              type="number"
              name="maximumPlayers"
              value={formData.participantInfo.maximumPlayers}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  participantInfo: {
                    ...prev.participantInfo,
                    maximumPlayers: e.target.value,
                  },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">기록</label>
            <input
              type="text"
              name="stats"
              value={formData.stats}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">시작 시간</label>
            <input
              type="datetime-local"
              name="startTime"
              value={formData.startTime}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">경기 시간(분)</label>
            <input
              type="number"
              name="durationMinutes"
              value={formData.durationMinutes}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">구장 ID</label>
            <input
              type="text"
              name="subFieldId"
              value={formData.subField._id}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  subField: { ...prev.subField, _id: e.target.value },
                }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block font-semibold mb-1">참가비</label>
            <input
              type="number"
              name="fee"
              value={formData.fee}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div className="flex justify-end space-x-4 mt-8">
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              저장
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
export default MatchEditPage;
